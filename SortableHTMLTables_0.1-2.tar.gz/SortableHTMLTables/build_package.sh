#!/bin/bash

rm SortableHTMLTables_*.tar.gz
rm -rf SortableHTMLTables.Rcheck
R CMD BUILD .
R CMD CHECK SortableHTMLTables_*.tar.gz
R CMD INSTALL SortableHTMLTables_*.tar.gz
